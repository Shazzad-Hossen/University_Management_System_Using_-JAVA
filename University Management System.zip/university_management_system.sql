-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2021 at 07:56 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_information`
--

CREATE TABLE `student_information` (
  `name` varchar(30) NOT NULL,
  `id` varchar(12) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `age` varchar(4) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_information`
--

INSERT INTO `student_information` (`name`, `id`, `phone`, `email`, `address`, `age`, `dob`) VALUES
('Shahriar Kabir', '191-15-2414', '01756234587', 'shahriar@gmail.com', 'YKSG', '22', '1999-04-15'),
('Shazzad Hossen', '191-15-2420', '01645288850', 'shazzad.srv@gmail.com', 'Sherpur Sadar, Sherpur', '24', '1998-10-11'),
('Tanjina Akter', '191-15-2440', '01845386862', 'tanjina@gmail.com', 'Mymensingh', '22', '1999-06-18'),
('Shohidul Islam Polash', '191-15-2523', '01734257862', 'shohidul15-2523@diu.edu.bd', 'dhaka Cantonment', '23', '1998-10-09'),
('Rina Sultana', '191-15-2560', '01745236489', 'rina15-2560@diu.edu.bd', 'Rajendrapur Cantonment', '30', '1991-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `student_login`
--

CREATE TABLE `student_login` (
  `id` varchar(12) NOT NULL,
  `password` varchar(30) NOT NULL,
  `active_status` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_login`
--

INSERT INTO `student_login` (`id`, `password`, `active_status`) VALUES
('191-15-2420', '1234', '1');

-- --------------------------------------------------------

--
-- Table structure for table `student_result`
--

CREATE TABLE `student_result` (
  `id` varchar(12) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `course1` varchar(50) NOT NULL,
  `grade1` double NOT NULL,
  `course2` varchar(50) NOT NULL,
  `grade2` double NOT NULL,
  `course3` varchar(50) NOT NULL,
  `grade3` double NOT NULL,
  `course4` varchar(50) NOT NULL,
  `grade4` double NOT NULL,
  `course5` varchar(50) NOT NULL,
  `grade5` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_result`
--

INSERT INTO `student_result` (`id`, `semester`, `course1`, `grade1`, `course2`, `grade2`, `course3`, `grade3`, `course4`, `grade4`, `course5`, `grade5`) VALUES
('191-15-2402', 'Fall 2020', 'Computer Fundamentals', 4, 'Basic Mathematics', 3, 'Basic Functional English and English Spoken', 3, 'Basic Physics', 4, 'Basic Physics Lab', 2),
('191-15-2420', 'Fall 2020', 'Object Oriented Programming II', 4, 'Software Project IV', 4, 'Numerical Methods', 4, 'Microprocessor, Embedded Systems and IoT\r\n', 4, 'Math for Computer Science', 4),
('191-15-2523', 'Fall 2020', 'Object Oriented Programming II', 4, 'Software Project IV', 4, 'Numerical Methods', 4, 'Microprocessor, Embedded Systems and IoT', 4, 'Math for Computer Science', 4);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_login`
--

CREATE TABLE `teacher_login` (
  `Name` varchar(30) NOT NULL,
  `employeeid` varchar(30) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `password` varchar(30) NOT NULL,
  `active_status` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_login`
--

INSERT INTO `teacher_login` (`Name`, `employeeid`, `Department`, `Email`, `phone`, `password`, `active_status`) VALUES
('Tasfia Anika Bushra', '1000', 'Computer Science & Engineering', 'tasfia.cse@diu.edu.bd', '01829298982', '1122', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_information`
--
ALTER TABLE `student_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_login`
--
ALTER TABLE `student_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_result`
--
ALTER TABLE `student_result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_login`
--
ALTER TABLE `teacher_login`
  ADD PRIMARY KEY (`employeeid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
